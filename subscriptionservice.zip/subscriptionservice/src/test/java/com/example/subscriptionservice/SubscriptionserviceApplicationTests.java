package com.example.subscriptionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubscriptionserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
